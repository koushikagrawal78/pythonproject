from faker.generator import Generator  # noqa F401
from faker.factory import Factory  # noqa F401

VERSION = '2.0.1'

Faker = Factory.create
